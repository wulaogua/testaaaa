<template>
    <div>
        dasdasadasdsad
       {{options.data}}       
    </div>
</template>

<script>
export default {
    created() {
    
    },
    mounted() {
        console.warn(this.options);
    },
    props:{
        options:{
            type:Object,
            default(){
                return {
                    data:0
                }
            }
        }
    },
    data() {
        return {
            
        }
    },
}
</script>

<style lang="scss" scoped>

</style>