import inputText from './input/text.vue'
import inputEmail from './input/email.vue'

export default {
    inputText, inputEmail
}
