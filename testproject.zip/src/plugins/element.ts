import ElementPlus from 'element-plus'
import 'element-plus/lib/theme-chalk/index.css'

export default (app:any) => {
  app.use(ElementPlus)
}
