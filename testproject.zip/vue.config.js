module.exports = {
  runtimeCompiler: true
}